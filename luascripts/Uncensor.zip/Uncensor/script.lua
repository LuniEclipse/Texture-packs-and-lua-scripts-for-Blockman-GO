-- Плагин для отключения цензуры (Uncensor)
local app_res_root = '/data/user/0/com.sandboxol.blockymods/app_resources/'
local words_path = app_res_root .. 'Media/Setting/words.txt'

-- Создаем папки, если их нет
local lfs = require('lfs')
pcall(function() lfs.mkdir(app_res_root .. 'Media') end)
pcall(function() lfs.mkdir(app_res_root .. 'Media/Setting') end)

-- Записываем пустой файл (или безобидное слово), чтобы отключить банворды
local f = io.open(words_path, 'w')
if f then
    -- Пишем только пробел, чтобы игра не ругалась на пустой файл
    f:write(" ") 
    f:close()
    print("UNCENSOR: words.txt successfully overwritten!")
else
    print("UNCENSOR: Failed to write words.txt")
end